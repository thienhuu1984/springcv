package funix.huutt.springcv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCvProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
